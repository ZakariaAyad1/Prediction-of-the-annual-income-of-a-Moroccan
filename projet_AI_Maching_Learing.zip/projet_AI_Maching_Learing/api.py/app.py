# --- Contenu de app.py ---
import streamlit as st
import pandas as pd
import requests # Pour appeler l'API FastAPI
from typing import List # Pour typer les listes

# --- Configuration de l'Application Streamlit ---
st.set_page_config(
    page_title="Prédiction Revenu Maroc",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- URL de l'API FastAPI ---
# Assurez-vous qu'elle correspond à l'adresse où l'API est lancée
API_URL = "http://127.0.0.1:8000/predict/"

# --- Définition des Catégories (pour les Selectbox) ---
# Doivent correspondre EXACTEMENT à api.py et generate_dataset.py
LIST_SEXES: List[str] = ['Homme', 'Femme']
LIST_LIEUX: List[str] = ['Urbain', 'Rural']
LIST_NIVEAUX_EDUCATION: List[str] = ['Sans niveau', 'Fondamental', 'Secondaire', 'Supérieur']
LIST_ETAT_MATRIMONIAL: List[str] = ['Célibataire', 'Marié', 'Divorcé', 'Veuf']
LIST_BIENS_POSSEDES: List[str] = ['Aucun', 'Voiture', 'Maison', 'Terrain', 'Voiture et Maison', 'Maison et Terrain', 'Tous']
LIST_CATEGORIES_SOCIO: List[str] = [
    'Cadres supérieurs', 'Cadres moyens / Commerçants', 'Inactifs',
    'Agriculteurs / Pêcheurs', 'Artisans / Ouvriers qualifiés', 'Manœuvres / Chômeurs'
]
LIST_ACCES_INTERNET: List[str] = ['Oui', 'Non']
LIST_TYPE_TRANSPORT: List[str] = ['Voiture', 'Transport en commun', 'Marche']


# --- Titre et Description ---
st.title("💰 Simulateur de Revenu Annuel au Maroc")
st.markdown("""
Bienvenue ! Cet outil utilise un modèle prédictif pour estimer le revenu annuel
d'un individu au Maroc.

**Instructions :** Renseignez les informations dans la barre latérale gauche, puis cliquez sur "Prédire".
""")
st.info("Note : Ceci est une simulation basée sur des données synthétiques et un modèle statistique. Les résultats sont indicatifs.", icon="ℹ️")
st.markdown("---")

# --- Fonction pour collecter les entrées utilisateur via la Sidebar ---
def user_input_features():
    st.sidebar.header("👤 Entrez les Caractéristiques")
    st.sidebar.markdown("👇 Remplissez tous les champs:")

    # --- Widgets Streamlit ---
    # Les clés du dictionnaire retourné doivent correspondre aux champs de InputFeatures dans api.py
    age = st.sidebar.slider(
        "🎂 Âge",
        min_value=18, max_value=70, value=35, step=1,
        help="Âge en années révolues."
    )
    experience = st.sidebar.slider(
        "📈 Années d'expérience",
        min_value=0, max_value=max(0, age - 18), value=min(10, max(0, age - 18)), step=1, # Expérience max dépend de l'âge
        help="Nombre total d'années d'expérience professionnelle."
    )
    enfants = st.sidebar.number_input(
        "👶 Nombre d'enfants",
        min_value=0, max_value=15, value=1, step=1,
        help="Nombre d'enfants à charge."
    )

    st.sidebar.markdown("---") # Séparateur

    sexe = st.sidebar.selectbox("⚧️ Sexe", options=LIST_SEXES, index=0)
    lieu = st.sidebar.selectbox("📍 Milieu de résidence", options=LIST_LIEUX, index=0)
    niveau_edu = st.sidebar.selectbox("🎓 Niveau d'éducation", options=LIST_NIVEAUX_EDUCATION, index=2) # Secondaire par défaut
    etat_mat = st.sidebar.selectbox("💍 État matrimonial", options=LIST_ETAT_MATRIMONIAL, index=1) # Marié par défaut

    st.sidebar.markdown("---") # Séparateur

    biens = st.sidebar.selectbox("🏡 Biens Possédés", options=LIST_BIENS_POSSEDES, index=1) # Voiture par défaut
    cat_socio = st.sidebar.selectbox("👔 Catégorie Socioprofessionnelle", options=LIST_CATEGORIES_SOCIO, index=4) # Artisan/Ouvrier par défaut
    internet = st.sidebar.selectbox("💻 Accès Internet", options=LIST_ACCES_INTERNET, index=0) # Oui par défaut
    transport = st.sidebar.selectbox("🚗 Type de Transport", options=LIST_TYPE_TRANSPORT, index=1) # Transport en commun par défaut

    # --- Création du dictionnaire ---
    data = {
        "Age": age,
        "Sexe": sexe,
        "Lieu": lieu,
        "Niveau_Education": niveau_edu,
        "Experience_Annees": experience,
        "Etat_Matrimonial": etat_mat,
        "Biens_Possedes": biens,
        "Categorie_Socioprofessionnelle": cat_socio,
        "Nombre_Enfants": enfants,
        "Acces_Internet": internet,
        "Type_Transport": transport
    }
    return data

# --- Collecter les données d'entrée ---
input_data = user_input_features()

# --- Afficher les données saisies dans la partie principale ---
st.subheader("📝 Récapitulatif des Informations Saisies :")
try:
    # Créer un DataFrame pour un affichage plus propre
    input_df_display = pd.DataFrame([input_data])
    # Transposer pour une meilleure lisibilité
    st.dataframe(input_df_display.T.rename(columns={0: 'Valeur Saisie'}), use_container_width=True)
except Exception as e:
    st.error(f"Erreur lors de l'affichage des données saisies: {e}")
st.markdown("---")

# --- Bouton pour lancer la prédiction ---
st.header("✨ Prédiction du Revenu")
# Utiliser des colonnes pour mieux centrer le bouton et le résultat
col_btn, col_result = st.columns([1, 2])

with col_btn:
    predict_button = st.button("🔮 Prédire le Revenu Annuel", type="primary", use_container_width=True)

with col_result:
    # Logique d'appel API et affichage du résultat
    if predict_button:
        # Afficher un spinner pendant l'appel API
        with st.spinner('🧠 Analyse en cours... Contact de l\'API...'):
            try:
                # Envoyer les données à l'API FastAPI via une requête POST
                # Utiliser json= pour envoyer le payload correctement formaté
                response = requests.post(API_URL, json=input_data, timeout=15) # Augmenter timeout si nécessaire

                # Vérifier si la requête a réussi (code de statut 2xx)
                response.raise_for_status() # Lève une exception pour 4xx/5xx

                # Extraire la prédiction de la réponse JSON
                prediction_data = response.json()

                if "revenu_annuel_predit_dh" in prediction_data:
                    revenu_predit = prediction_data['revenu_annuel_predit_dh']

                    # Afficher le résultat avec mise en forme
                    st.success(f"**Estimation Réussie !**")
                    st.metric(label="Revenu Annuel Estimé (DH)", value=f"{revenu_predit:,.2f} DH")

                    # Ajouter une petite interprétation/contexte
                    revenu_moyen_national = 21949 # Rappel de l'énoncé
                    delta = revenu_predit - revenu_moyen_national
                    percent_diff = (delta / revenu_moyen_national) * 100 if revenu_moyen_national else 0

                    st.info(f"""
                    **Comparaison (indicative) :**
                    *   Moyenne Nationale (simulée): {revenu_moyen_national:,.2f} DH/an.
                    *   Différence: {delta:,.2f} DH ({percent_diff:+.1f}% vs moyenne).
                    """, icon="📊")

                # Gérer le cas où l'API retourne une erreur métier structurée (ex: Pydantic validation)
                elif "detail" in prediction_data:
                    st.error(f"⚠️ Erreur retournée par l'API :")
                    # Afficher les détails si c'est une liste d'erreurs Pydantic
                    if isinstance(prediction_data['detail'], list):
                        for error in prediction_data['detail']:
                            st.error(f"- Champ '{error.get('loc', ['Inconnu'])[-1]}': {error.get('msg', 'Erreur inconnue')}")
                    else:
                         st.error(f"{prediction_data['detail']}")
                else:
                     st.error("❌ Réponse inattendue reçue de l'API.")
                     st.json(prediction_data) # Afficher la réponse brute

            # --- Gestion des Erreurs de Requête ---
            except requests.exceptions.ConnectionError:
                st.error(f"❌ Connexion Impossible à l'API ({API_URL}).")
                st.error("Veuillez vérifier que l'API FastAPI est bien lancée et accessible.")
            except requests.exceptions.Timeout:
                 st.error("❌ Le délai d'attente pour la réponse de l'API a été dépassé.")
            except requests.exceptions.HTTPError as http_err:
                 status_code = http_err.response.status_code
                 st.error(f"❌ Erreur HTTP {status_code} lors de l'appel à l'API.")
                 try:
                      # Essayer d'afficher le message d'erreur de l'API
                      error_detail = http_err.response.json().get("detail", http_err.response.text)
                      st.error(f"Détail API: {error_detail}")
                 except Exception:
                      st.error("Impossible d'obtenir le détail de l'erreur depuis la réponse de l'API.")
            except Exception as e:
                 st.error(f"❌ Une erreur inattendue est survenue dans l'application Streamlit :")
                 st.exception(e) # Affiche l'exception complète pour le débogage
    else:
        st.info("Cliquez sur le bouton 'Prédire' pour obtenir une estimation.")


# --- Pied de page ---
st.markdown("---")
st.markdown("== Prédiction de Revenu ==")
st.markdown("- Encadré Par : Yacine EL YOUNOUSSI")
st.markdown("- Auteur:[jihane EL AMRANI , Hala QUERRICH , Zakariya AYAD] ")
st.markdown("- Mai 2025 ")