# --- Contenu de api.py ---
from fastapi import FastAPI, HTTPException
import uvicorn
import joblib
import pandas as pd
from pydantic import BaseModel, Field, validator # Importer Field et validator
import numpy as np
import warnings
from typing import List # Pour typer les listes de catégories

# Ignorer les avertissements potentiels de scikit-learn/joblib ou Pydantic
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

# --- Définition Globale des Catégories Possibles ---
SEXES: List[str] = ['Homme', 'Femme']
LIEUX: List[str] = ['Urbain', 'Rural']
NIVEAUX_EDUCATION: List[str] = ['Sans niveau', 'Fondamental', 'Secondaire', 'Supérieur']
ETAT_MATRIMONIAL: List[str] = ['Célibataire', 'Marié', 'Divorcé', 'Veuf']
BIENS_POSSEDES: List[str] = ['Aucun', 'Voiture', 'Maison', 'Terrain', 'Voiture et Maison', 'Maison et Terrain', 'Tous']
CATEGORIES_SOCIO: List[str] = [
    'Cadres supérieurs', 'Cadres moyens / Commerçants', 'Inactifs',
    'Agriculteurs / Pêcheurs', 'Artisans / Ouvriers qualifiés', 'Manœuvres / Chômeurs'
]
ACCES_INTERNET: List[str] = ['Oui', 'Non']
TYPE_TRANSPORT: List[str] = ['Voiture', 'Transport en commun', 'Marche']

# --- Liste Ordonnée des Colonnes Attendues par le Modèle (pré-transformation) ---
# Basée sur l'ordre dans generate_dataset.py avant 'Revenu_Annuel'
# C'est crucial pour que pd.DataFrame ait le bon ordre si ColumnTransformer s'y fie
ORIGINAL_FEATURE_NAMES: List[str] = [
    'Age', 'Sexe', 'Lieu', 'Niveau_Education', 'Experience_Annees',
    'Etat_Matrimonial', 'Biens_Possedes', 'Categorie_Socioprofessionnelle',
    'Nombre_Enfants', 'Acces_Internet', 'Type_Transport'
]

# 1. Initialiser l'application FastAPI
app = FastAPI(
    title="API Prédiction Revenu Marocain",
    description="Prédit le revenu annuel basé sur des caractéristiques socio-démographiques.",
    version="1.1.0" # Incrément de version
)

# 2. Charger le modèle sauvegardé (pipeline complet)
try:
    model = joblib.load('modele_selection.joblib')
    print("✅ Modèle 'modele_selection.joblib' chargé avec succès.")
except FileNotFoundError:
    print("❌ ERREUR CRITIQUE: Fichier modèle 'modele_selection.joblib' non trouvé.")
    model = None
except Exception as e:
    print(f"❌ ERREUR CRITIQUE: Erreur lors du chargement du modèle: {e}")
    model = None

# 3. Définir la structure des données d'entrée avec Pydantic
class InputFeatures(BaseModel):
    Age: int = Field(..., example=35, description="Âge de l'individu (années)")
    Sexe: str = Field(..., example="Homme", description=f"Sexe ({', '.join(SEXES)})")
    Lieu: str = Field(..., example="Urbain", description=f"Milieu de résidence ({', '.join(LIEUX)})")
    Niveau_Education: str = Field(..., example="Supérieur", description=f"Niveau d'éducation ({', '.join(NIVEAUX_EDUCATION)})")
    Experience_Annees: int = Field(..., example=10, description="Années d'expérience professionnelle")
    Etat_Matrimonial: str = Field(..., example="Marié", description=f"État matrimonial ({', '.join(ETAT_MATRIMONIAL)})")
    Biens_Possedes: str = Field(..., example="Voiture et Maison", description=f"Biens possédés ({', '.join(BIENS_POSSEDES)})")
    Categorie_Socioprofessionnelle: str = Field(..., example="Cadres moyens / Commerçants", description=f"Catégorie socioprofessionnelle ({', '.join(CATEGORIES_SOCIO)})")
    Nombre_Enfants: int = Field(..., example=2, description="Nombre d'enfants à charge")
    Acces_Internet: str = Field(..., example="Oui", description=f"Accès à Internet ({', '.join(ACCES_INTERNET)})")
    Type_Transport: str = Field(..., example="Voiture", description=f"Mode de transport principal ({', '.join(TYPE_TRANSPORT)})")

    # --- Validateurs pour les champs catégoriels ---
    @validator('*', pre=True, allow_reuse=True) # Vérifie toutes les chaines avant validation spécifique
    def check_empty_string(cls, v):
        if isinstance(v, str) and not v.strip():
            raise ValueError("Champ texte ne peut pas être vide")
        return v

    @validator('Sexe')
    def check_sexe(cls, v):
        if v not in SEXES: raise ValueError(f"Sexe doit être un de : {SEXES}")
        return v
    @validator('Lieu')
    def check_lieu(cls, v):
        if v not in LIEUX: raise ValueError(f"Lieu doit être un de : {LIEUX}")
        return v
    @validator('Niveau_Education')
    def check_education(cls, v):
        if v not in NIVEAUX_EDUCATION: raise ValueError(f"Niveau_Education doit être un de : {NIVEAUX_EDUCATION}")
        return v
    @validator('Etat_Matrimonial')
    def check_etat(cls, v):
        if v not in ETAT_MATRIMONIAL: raise ValueError(f"Etat_Matrimonial doit être un de : {ETAT_MATRIMONIAL}")
        return v
    @validator('Biens_Possedes')
    def check_biens(cls, v):
        if v not in BIENS_POSSEDES: raise ValueError(f"Biens_Possedes doit être un de : {BIENS_POSSEDES}")
        return v
    @validator('Categorie_Socioprofessionnelle')
    def check_categorie(cls, v):
        if v not in CATEGORIES_SOCIO: raise ValueError(f"Categorie_Socioprofessionnelle doit être un de : {CATEGORIES_SOCIO}")
        return v
    @validator('Acces_Internet')
    def check_internet(cls, v):
        if v not in ACCES_INTERNET: raise ValueError(f"Acces_Internet doit être un de : {ACCES_INTERNET}")
        return v
    @validator('Type_Transport')
    def check_transport(cls, v):
        if v not in TYPE_TRANSPORT: raise ValueError(f"Type_Transport doit être un de : {TYPE_TRANSPORT}")
        return v

    # --- Configuration Pydantic pour l'exemple dans /docs ---
    class Config:
        schema_extra = {
            "example": {
                "Age": 42,
                "Sexe": "Femme",
                "Lieu": "Urbain",
                "Niveau_Education": "Secondaire",
                "Experience_Annees": 15,
                "Etat_Matrimonial": "Marié",
                "Biens_Possedes": "Maison",
                "Categorie_Socioprofessionnelle": "Artisans / Ouvriers qualifiés",
                "Nombre_Enfants": 3,
                "Acces_Internet": "Oui",
                "Type_Transport": "Transport en commun"
            }
        }

# 4. Créer endpoint de prédiction
@app.post(
    "/predict/",
    summary="Prédire le revenu annuel",
    response_description="Le revenu annuel prédit en Dirhams marocains (DH)",
    tags=["Prédiction"] # Organisation des endpoints dans /docs
)
async def predict_income(features: InputFeatures):
    """
    Prédit le revenu annuel d'un individu marocain.

    Fournir toutes les caractéristiques listées dans le schéma `InputFeatures`.
    """
    if model is None:
        print("❌ Tentative d'appel à /predict/ mais le modèle n'est pas chargé.")
        raise HTTPException(status_code=503, detail="Modèle de prédiction non disponible.") # Service Unavailable

    try:
        # Convertir les données d'entrée Pydantic en dictionnaire
        input_data = features.dict()
        # Créer un DataFrame Pandas à partir du dictionnaire
        input_df = pd.DataFrame([input_data])

        # **Réorganiser les colonnes pour correspondre à l'entraînement**
        input_df = input_df[ORIGINAL_FEATURE_NAMES]

    except KeyError as e:
        # Ne devrait pas arriver grâce à Pydantic, mais sécurité
        print(f"❌ Erreur de clé lors de la création du DataFrame : {e}")
        raise HTTPException(status_code=400, detail=f"Donnée manquante ou clé invalide : {e}")
    except Exception as e:
        print(f"❌ Erreur lors de la préparation des données : {e}")
        raise HTTPException(status_code=400, detail=f"Erreur lors de la préparation des données d'entrée: {e}")

    # Faire la prédiction
    try:
        print(f"⏳ Prédiction pour les données : {input_data}")
        prediction = model.predict(input_df)

        # Extraire la valeur prédite (souvent un array numpy)
        predicted_income = float(prediction[0])
        print(f"✅ Prédiction réussie : {predicted_income:.2f} DH")

    except ValueError as ve:
        # Erreur si types/catégories inattendus par le pipeline malgré Pydantic
        print(f"❌ Erreur de valeur lors de la prédiction : {ve}")
        print(f"DataFrame passé au modèle:\n{input_df.to_string()}")
        raise HTTPException(status_code=422, detail=f"Erreur dans les valeurs fournies au modèle : {ve}") # Unprocessable Entity
    except Exception as e:
        # Capturer toute autre erreur durant model.predict
        print(f"❌ Erreur inattendue lors de l'exécution de model.predict : {e}")
        print(f"DataFrame passé au modèle:\n{input_df.to_string()}")
        raise HTTPException(status_code=500, detail=f"Erreur interne du serveur lors de la prédiction : {e}")

    # Retourner la prédiction formatée
    return {"revenu_annuel_predit_dh": round(predicted_income, 2)}


# --- Section 5 : Point de terminaison racine (TEMPORAIREMENT SIMPLIFIÉ) ---
@app.get(
    "/",
    summary="Statut de l'API (Simple Test)",
    response_description="Message de test simple",
    tags=["Statut"]
)
async def read_root_simple_test():
    print("🚦 Requête reçue sur / (endpoint simplifié)") # Ajoutez un print
    return {"message": "Test simple de l'API - OK"}





# --- Point d'entrée pour Uvicorn (si vous exécutez `python api.py`) ---
if __name__ == "__main__":
    print("🚀 Lancement de l'API FastAPI avec Uvicorn sur http://127.0.0.1:8000")
    uvicorn.run(app, host="127.0.0.1", port=8000)

# Pour lancer depuis le terminal (recommandé pour le développement):
# uvicorn api:app --reload